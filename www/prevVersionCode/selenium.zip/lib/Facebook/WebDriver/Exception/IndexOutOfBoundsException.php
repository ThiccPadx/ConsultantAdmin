<?php

namespace Facebook\WebDriver\Exception;

class IndexOutOfBoundsException extends WebDriverException {

}