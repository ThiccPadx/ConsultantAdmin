<?php
session_start();
require_once('db.php');
require_once('library.php');
?>