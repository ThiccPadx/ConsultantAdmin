<script type="text/javascript" src="assets/js/jquery-1.12.0.min.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.js"></script>
<script type="text/javascript" src="assets/vendor/bootstrap-confirmation/bootstrap-confirmation.js"></script>
<script type="text/javascript" src="assets/vendor/bootstrap-daterangepicker/moment.js"></script>
<script type="text/javascript" src="assets/vendor/bootstrap-daterangepicker/daterangepicker.js"></script>
<script type="text/javascript" src="assets/vendor/jquery-validate/jquery.validate.min.js"></script>
<script type="text/javascript" src="assets/vendor/jquery-inputmask/inputmask.js"></script>
<script type="text/javascript" src="assets/vendor/jquery-inputmask/jquery.inputmask.js"></script>
<script type="text/javascript" src="assets/js/main.js"></script>
</div><!-- #content_wrapper -->
</body>
</html>