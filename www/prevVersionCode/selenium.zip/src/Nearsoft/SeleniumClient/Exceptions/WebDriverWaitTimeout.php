<?php
namespace Nearsoft\SeleniumClient\Exceptions;

class WebDriverWaitTimeout extends \Exception {}